# data_splitter
[![Splitter CI/CD](https://github.com/michelefontana92/data_splitter/actions/workflows/splitter_ci.yaml/badge.svg)](https://github.com/michelefontana92/data_splitter/actions/workflows/splitter_ci.yaml)

![badge](https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/michelefontana92/4c10a1f1f4cfc1d98e4ed48ca189628b/raw/pytest_coverage.json)