import pandas as pd

for i in range(10):
    df = pd.read_csv(f'data/Adult/adult_agent_{i}.csv')
    print('Agent ', i)
    print(df.info())
    print('\n')