import pandas as pd 
from sklearn.model_selection import train_test_split


df = pd.read_csv('fake_adult.csv').drop_duplicates()
y = df.pop('income')
n_samples = 200000
# perform a stratified sampling to split the data
X_train, X_test, y_train, y_test = train_test_split(df,
                                                     y, 
                                                     test_size=n_samples,
                                                    random_state=42, 
                                                    stratify=y)

# create a new dataframe with the stratified samples
df_test = pd.concat([X_test, y_test], axis=1).reset_index(drop=True)
df_test.to_csv(f'fake_adult_sample.csv', index=False)
print(df_test.columns)
print(df_test.head())
print(len(df_test))