import pandas as pd
from icecream import ic
import numpy as np
import pytest
from src import QuantitySkewSplitter


@pytest.fixture
def data():
    data = pd.read_csv('data/Adult/adult.csv')
    ic(data.head())
    ic(data.info())
    return {'data': data,
            'target': 'income',
            'class_names': ['<=50K', '>50K']}


@pytest.mark.parametrize("alpha", [0.1, 0.3, 0.5, 1.0, 50])
@pytest.mark.parametrize("n_samples", [1])
@pytest.mark.parametrize("vector_dimension", [2, 3, 5, 10])
def test_quantity_skew_splitter(data: dict, alpha: float, vector_dimension: int, n_samples: int):
    assert data is not None
    X = data['data']
    target = data['target']
    qs_splitter = QuantitySkewSplitter(
        alpha=alpha, vector_dimension=vector_dimension)
    assert qs_splitter is not None
    total_length = 0

    ic(f'The original dataset has:\n{len(X)} samples\n\
{len(X[target].unique())} classes\n\
{X[target].value_counts()}\n\n')

    for node_id, df in enumerate(qs_splitter(data)):
        assert df is not None
        total_length += len(df)
        ic(f'Agent {node_id} has:\n{len(df)} samples\n\
{len(df[data["target"]].unique())} classes\n\
{df[data["target"]].value_counts()}\n\n')
    assert total_length == len(data['data'])


def test_quantity_skew_splitter_data_none():
    qs_splitter = QuantitySkewSplitter()
    with pytest.raises(AssertionError):
        qs_splitter.split(None)
    with pytest.raises(AssertionError):
        qs_splitter(None)
