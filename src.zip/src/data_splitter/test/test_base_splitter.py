from src import BaseSplitter
import pandas as pd
from icecream import ic
import numpy as np
import pytest


@pytest.fixture
def data():
    data = pd.read_csv('data/Adult/adult.csv')
    ic(data.head())
    ic(data.info())
    return {'data': data,
            'target': 'income',
            'class_names': ['<=50K', '>50K']}


def test_base_splitter_exception(data: dict):
    base_splitter = BaseSplitter()
    with pytest.raises(NotImplementedError):
        base_splitter.split(data)
    with pytest.raises(NotImplementedError):
        base_splitter(data)
