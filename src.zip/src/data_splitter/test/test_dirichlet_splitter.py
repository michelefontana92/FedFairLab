from src import DirichletSplitter
import pandas as pd
from icecream import ic
import numpy as np
import pytest


@pytest.fixture
def data():
    data = pd.read_csv('data/Adult/adult.csv')
    ic(data.head())
    ic(data.info())
    return {'data': data,
            'target': 'income',
            'class_names': ['<=50K', '>50K']}

"""
@pytest.mark.parametrize("alpha", [0.1, 0.3, 0.5, 1.0, 50])
@pytest.mark.parametrize("n_samples", [2])
@pytest.mark.parametrize("vector_dimension", [2, 3, 5, 10])
def test_dirichlet_splitter(data: dict, alpha: float, vector_dimension: int, n_samples: int):
    assert data is not None
    X = data['data']
    target = data['target']
    dirichlet_splitter = DirichletSplitter(
        alpha=alpha, vector_dimension=vector_dimension)

    assert dirichlet_splitter is not None
    total_length = 0
    total_samples_class_0 = 0
    total_samples_class_1 = 0
    total_samples_class_0_origin = len(X[X[target] == '<=50K'])
    total_samples_class_1_origin = len(X[X[target] == '>50K'])

    ic(f'The original dataset has:\n{len(X)} samples\n\
{len(X[target].unique())} classes\n\
{X[target].value_counts()}\n\n')
    for node_id, df in enumerate(dirichlet_splitter(data)):
        assert df is not None
        total_length += len(df)
        total_samples_class_0 += len(df[df[target] == '<=50K'])
        total_samples_class_1 += len(df[df[target] == '>50K'])

        ic(f'Agent {node_id} has:\n{len(df)} samples\n\
{len(df[data["target"]].unique())} classes\n\
{df[data["target"]].value_counts()}\n\n')

    assert total_length == len(data['data'])
    assert total_samples_class_0 == total_samples_class_0_origin
    assert total_samples_class_1 == total_samples_class_1_origin


def test_dirichlet_data_none():
    dirichlet_splitter = DirichletSplitter()
    with pytest.raises(AssertionError):
        dirichlet_splitter.split(None)
    with pytest.raises(AssertionError):
        dirichlet_splitter(None)
"""
@pytest.mark.parametrize("alpha", [1])
@pytest.mark.parametrize("n_samples", [2])
@pytest.mark.parametrize("vector_dimension", [5])
def test_dirichlet_attribute_split(data: dict, alpha: float, vector_dimension: int, n_samples: int):
    X = data['data']
    target = data['target']
    attributes = ['gender','income']
    dirichlet_splitter = DirichletSplitter(
        alpha=alpha, vector_dimension=vector_dimension)
    for node_id, df in enumerate(dirichlet_splitter(data,
                                                    attributes=attributes)):
        assert df is not None
        ic(f'Agent {node_id} has:\n{len(df)} samples\n{df[attributes].value_counts()}\n\n')