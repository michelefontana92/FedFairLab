from src import CustomDistributionSplitter
import pandas as pd
from icecream import ic
import numpy as np
import pytest


@pytest.fixture
def data():
    data = pd.read_csv('data/Adult/adult.csv')
    ic(data.head())
    ic(data.info())
    return {'data': data,
            'target': 'income',
            'class_names': ['<=50K', '>50K']}


@pytest.mark.parametrize("vector_dimension", [2])
def test_custom_splitter_custom_distribution_2_agents(data: dict, vector_dimension: int):
    assert data is not None
    X = data['data']
    target = data['target']
    custom_splitter = CustomDistributionSplitter(
        vector_dimension=vector_dimension)
    custom_distribution = [
        [0.9, 0.1],
        [0.2, 0.8],
    ]
    assert custom_splitter is not None
    total_length = 0
    total_samples_class_0 = 0
    total_samples_class_1 = 0
    total_samples_class_0_origin = len(X[X[target] == '<=50K'])
    total_samples_class_1_origin = len(X[X[target] == '>50K'])

    ic(f'The original dataset has:\n{len(X)} samples\n\
{len(X[target].unique())} classes\n\
{X[target].value_counts()}\n\n')
    for node_id, df in enumerate(custom_splitter(data, distribution=custom_distribution)):
        assert df is not None
        total_length += len(df)
        total_samples_class_0 += len(df[df[target] == '<=50K'])
        total_samples_class_1 += len(df[df[target] == '>50K'])

        ic(f'Agent {node_id} has:\n{len(df)} samples\n\
{len(df[data["target"]].unique())} classes\n\
{df[data["target"]].value_counts()}\n\n')

    assert total_length == len(data['data'])
    assert total_samples_class_0 == total_samples_class_0_origin
    assert total_samples_class_1 == total_samples_class_1_origin


@pytest.mark.parametrize("vector_dimension", [3])
def test_custom_splitter_custom_distribution_3_agents(data: dict, vector_dimension: int):
    assert data is not None
    X = data['data']
    target = data['target']
    custom_splitter = CustomDistributionSplitter(
        vector_dimension=vector_dimension)
    custom_distribution = [
        [0.8, 0.1, 0.1],
        [0.2, 0.5, 0.3],
    ]
    assert custom_splitter is not None
    total_length = 0
    total_samples_class_0 = 0
    total_samples_class_1 = 0
    total_samples_class_0_origin = len(X[X[target] == '<=50K'])
    total_samples_class_1_origin = len(X[X[target] == '>50K'])

    ic(f'The original dataset has:\n{len(X)} samples\n\
{len(X[target].unique())} classes\n\
{X[target].value_counts()}\n\n')
    for node_id, df in enumerate(custom_splitter(data, distribution=custom_distribution)):
        assert df is not None
        total_length += len(df)
        total_samples_class_0 += len(df[df[target] == '<=50K'])
        total_samples_class_1 += len(df[df[target] == '>50K'])

        ic(f'Agent {node_id} has:\n{len(df)} samples\n\
{len(df[data["target"]].unique())} classes\n\
{df[data["target"]].value_counts()}\n\n')

    assert total_length == len(data['data'])
    assert total_samples_class_0 == total_samples_class_0_origin
    assert total_samples_class_1 == total_samples_class_1_origin


@pytest.mark.parametrize("vector_dimension", [2])
def test_custom_splitter_wrong_custom_distribution(data: dict, vector_dimension: int):
    assert data is not None
    X = data['data']
    target = data['target']
    custom_splitter = CustomDistributionSplitter(
        vector_dimension=vector_dimension)
    custom_distribution_wrong_size_class = [
        [0.9, 0.1],
        [0.1, 0.9],
        [0.1, 0.9]
    ]

    with pytest.raises(AssertionError):
        custom_splitter(
            data, distribution=custom_distribution_wrong_size_class)
    custom_distribution_wrong_size_class = [
        [0.9, 0.1]
    ]

    with pytest.raises(AssertionError):
        custom_splitter(
            data, distribution=custom_distribution_wrong_size_class)
    custom_distribution_wrong_size_vector = [
        [0.6, 0.2, 0.2],
        [0.6, 0.2, 0.2]

    ]

    with pytest.raises(AssertionError):
        custom_splitter(
            data, distribution=custom_distribution_wrong_size_vector)
    custom_distribution_wrong_sum = [
        [0.6, 0.4],
        [0.6, 0.2]

    ]

    with pytest.raises(AssertionError):
        custom_splitter(
            data, distribution=custom_distribution_wrong_sum)
    custom_distribution_wrong_sum = [
        [0.6, 0.4],
        [0.6, 0.5]

    ]

    with pytest.raises(AssertionError):
        custom_splitter(
            data, distribution=custom_distribution_wrong_sum)

    custom_distribution_wrong_type = [
        0.6, 0.4

    ]

    with pytest.raises(AssertionError):
        custom_splitter(
            data, distribution=custom_distribution_wrong_type)

    custom_distribution_wrong_type = (0.6, 0.4)
    with pytest.raises(AssertionError):
        custom_splitter(
            data, distribution=custom_distribution_wrong_type)


@pytest.mark.parametrize("vector_dimension", [3])
def test_custom_splitter_iid(data: dict, vector_dimension: int):
    assert data is not None
    X = data['data']
    target = data['target']
    custom_splitter = CustomDistributionSplitter(
        vector_dimension=vector_dimension)

    assert custom_splitter is not None
    total_length = 0
    total_samples_class_0 = 0
    total_samples_class_1 = 0
    total_samples_class_0_origin = len(X[X[target] == '<=50K'])
    total_samples_class_1_origin = len(X[X[target] == '>50K'])

    ic(f'The original dataset has:\n{len(X)} samples\n\
{len(X[target].unique())} classes\n\
{X[target].value_counts()}\n\n')
    for node_id, df in enumerate(custom_splitter(data)):
        assert df is not None
        total_length += len(df)
        total_samples_class_0 += len(df[df[target] == '<=50K'])
        total_samples_class_1 += len(df[df[target] == '>50K'])

        ic(f'Agent {node_id} has:\n{len(df)} samples\n\
{len(df[data["target"]].unique())} classes\n\
{df[data["target"]].value_counts()}\n\n')

    assert total_length == len(data['data'])
    assert total_samples_class_0 == total_samples_class_0_origin
    assert total_samples_class_1 == total_samples_class_1_origin


def test_custom_data_none():
    custom_splitter = CustomDistributionSplitter()
    with pytest.raises(AssertionError):
        custom_splitter.split(None)
    with pytest.raises(AssertionError):
        custom_splitter(None)
