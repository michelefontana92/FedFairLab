from src import DirichletSplitter, IIDSplitter, CustomDistributionSplitter, BaseSplitter, QuantitySkewSplitter
import pandas as pd
from icecream import install, ic
import numpy as np
import click
import os
import json
# create the time measurement (seconds, minutes, hours) decorator
from time import time
from functools import wraps, partial
from sklearn.model_selection import train_test_split

def timing(f):
    @wraps(f)
    def wrap(*args, **kw):
        ts = time()
        result = f(*args, **kw)
        te = time()
        ic(f'\n func:{f.__name__} args:[{args}, {kw}]\n took: ({round(te-ts,3)} sec {round((te-ts)/60,3)} mins {round((te-ts)/(60*60),3)} hours)  to complete')
        return result
    return wrap

def stratify_split(df, sensitive_attributes, target, save_path,prefix):
    print('Totale record iniziali:', len(df))

    # Crea label congiunto
    df['stratify_label'] = df[sensitive_attributes+ [target]].astype(str).agg('_'.join, axis=1)

    # Rimuovi gruppi troppo piccoli
    group_counts = df['stratify_label'].value_counts()
    small_groups = group_counts[group_counts <= 10].index
    df = df[~df['stratify_label'].isin(small_groups)]

    print(f"[✓] Rimosso {len(small_groups)} gruppi con <=30 record")
    print(f"[✓] Rimanenti per stratificazione: {len(df)}")

    # Split stratificato
    y = df[target]
    X = df.drop(columns=[target, 'stratify_label'])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.5, stratify=df['stratify_label']
    )

    df_train = pd.concat([X_train, y_train], axis=1).reset_index(drop=True)
    df_test = pd.concat([X_test, y_test], axis=1).reset_index(drop=True)
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    df_train.to_csv(f'{save_path}/{prefix}_train.csv', index=False)
    df_test.to_csv(f'{save_path}/{prefix}_val.csv', index=False)

    print(f"[✓] Train: {len(df_train)} | Test: {len(df_test)}")


def output_to_file(filename, text):
    with open(filename, 'a') as f:
        f.write(f'{text}\n')


# split a list into k sublists
def split_list(l, k):
    n = len(l)
    return [l[i*n//k: (i+1)*n//k] for i in range(k)]

# read the parameters from the json file


def read_parameters_from_json(json_file):
    with open(json_file, 'r') as f:
        parameters = json.load(f)
    return parameters

# read the parameters from the command line


@click.command()
@click.option('--config', '-c', is_flag=False, flag_value='config.json',
              help='Path to the configuration file')
@click.option('--splitter', default='dirichlet',
              type=click.Choice(
                  ['dirichlet', 'iid', 'custom', 'quantity'],
                  case_sensitive=False),
              help='Splitter to use')
@click.option('--alpha', '-a', default=0.1, help='Dirichlet distribution parameter')
@click.option('--n_agents', '-n', default=2, help='Number of agents')
@click.option('--custom_distribution', '-cd', multiple=True, default=[0.5],
              help='Custom distribution')
@click.option('--data_path', '-dp', default='data/Adult/adult.csv', help='Path to the dataset')
@click.option('--target', '-t', default='income', help='Target column')
@click.option('--class_names', '-cn', default=['<=50K'], multiple=True,

              help='Class names')
@click.option('--save_path', '-s', default='data/Adult', help='Path to the directory where to save the dataset')
@click.option('--prefix', '-p', default='adult', help='Prefix of filename to be saved')
@click.option('--verbose', '-v', is_flag=True, show_default=True, default=False, help='Verbosity')
@click.option('--log_file', '-lf', default='output.log', help='Path to the log file')
@click.option('--log_dir', '-ld', default='logs', help='Path to the log directory')
@timing
def main(config, splitter, alpha, n_agents, custom_distribution,
         data_path, target, class_names,
         save_path, prefix, verbose, log_dir, log_file):

    # Read the parameters from the json file if it is provided. If not, use the command line parameters. If a parameter is not provided, use the default value
    if config:
        parameters = read_parameters_from_json(config)
        splitter = parameters.get('splitter', splitter)
        alpha = parameters.get('alpha', alpha)
        n_agents = parameters.get('n_agents', n_agents)
        custom_distribution = parameters.get(
            'custom_distribution', custom_distribution)
        data_path = parameters.get('data_path', data_path)
        target = parameters.get('target', target)
        class_names = parameters.get('class_names', class_names)
        save_path = parameters.get('save_path', save_path)
        prefix = parameters.get('prefix', prefix)
        verbose = parameters.get('verbose', verbose)
        log_file = parameters.get('log_file', log_file)
        log_dir = parameters.get('log_dir', log_dir)
        attributes = parameters.get('attributes', [])
        cat_cols = parameters.get('cat_cols', [])
    
    #if target not in attributes:
    #    attributes.append(target)
    # if the save path does not exist, create it
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    # if the log dir path does not exist, create it
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # initialize the ic() function
    install()
    ic.configureOutput(prefix='debug-', includeContext=True,
                       outputFunction=partial(output_to_file,
                                              f'{log_dir}/{log_file}'))

    df = pd.read_csv(data_path)
    class_names = list(class_names)
    if verbose:
        ic(class_names)
        ic(df.head())
        ic(df.info())
    data = {'data': df,
            'target': target,
            'class_names': class_names}
    assert data is not None
    X = data['data']
    target = data['target']
    # Create the splitter
    if splitter == 'dirichlet':
        if verbose:
            ic(f'Using DirichletSplitter with alpha={alpha}')
        splitter = DirichletSplitter(
            alpha=alpha, vector_dimension=n_agents)
    elif splitter == 'iid':
        if verbose:
            ic(f'Using IIDSplitter with vector_dimension={n_agents}')
        splitter = IIDSplitter(
            vector_dimension=n_agents)
    elif splitter == 'custom':
        if verbose:
            custom_distribution = np.asfarray(custom_distribution).reshape(
                len(class_names), n_agents).tolist()

            ic(f'Using CustomDistributionSplitter with custom_distribution={custom_distribution}')
        splitter = CustomDistributionSplitter(
            vector_dimension=n_agents)
    elif splitter == 'quantity':
        if verbose:
            ic(f'Using QuantitySkewSplitter with alpha={alpha}')
        splitter = QuantitySkewSplitter(
            alpha=alpha, vector_dimension=n_agents)
    else:
        raise ValueError('Invalid splitter')

    assert splitter is not None

    print(f'Using {splitter.__class__.__name__} with parameters: {splitter}')
    print('Attributes:', attributes)
    # Use the splitter to split the data
    for node_id, df in enumerate(splitter(data,
                                          distribution=custom_distribution,
                                          attributes=attributes,
                                          cat_cols=cat_cols)):
        assert df is not None
        df.drop('group_id',axis=1,inplace=True)
        if verbose:
            print(f'Agent {node_id} has:\n{len(df)} samples\n\
            {len(df[data["target"]].unique())} classes\n\
            {df[data["target"]].value_counts()}\n\n')
        # Save the data
        df.to_csv(f'{save_path}/{prefix}_agent_{node_id}.csv', index=False)
        stratify_split(df, attributes, target, f'{save_path}/node_{node_id+1}',prefix)
        """
        y = df.pop(target)
        X_train, X_test, y_train, y_test = train_test_split(
                    df,y,test_size=0.2,
                    random_state=42,stratify=y)
        # create a new dataframe with the stratified samples
        df_train = pd.concat([X_train, y_train], axis=1).reset_index(drop=True)
        df_test = pd.concat([X_test, y_test], axis=1).reset_index(drop=True)
        dir_name = f'{save_path}/node_{node_id+1}'
        if not os.path.exists(dir_name):
            os.makedirs(dir_name,exist_ok=True)
        df_train.to_csv(f'{dir_name}/{prefix}_train.csv', index=False)
        df_test.to_csv(f'{dir_name}/{prefix}_val.csv', index=False)
        print()
        print('Agent ',node_id)
        print('Train data\n')
        print(df_train[target].value_counts())
        print(df_train.info())
        print('Test data\n')
        print(df_test[target].value_counts())
        print(df_test.info())
        
        print()
        """
if __name__ == '__main__':
    main()
