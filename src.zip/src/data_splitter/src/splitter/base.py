class BaseSplitter:
    def __init__(self, *args, **kwargs):
        self.kwargs = kwargs
        self.args = args

    def split(self, data, **kwargs):
        raise NotImplementedError

    def __call__(self, data, **kwargs):
        return self.split(data, **kwargs)
