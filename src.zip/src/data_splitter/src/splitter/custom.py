from .base import BaseSplitter
from icecream import ic
import numpy as np
import pandas as pd
from math import ceil


class CustomDistributionSplitter(BaseSplitter):
    def __init__(self, *args, **kwargs) -> None:
        print("CustomDistributionSplitter created")
        super().__init__(*args, **kwargs)
        self.vector_dimension = kwargs.get('vector_dimension', 2)

    def split(self, data, **kwargs):
        assert data is not None
        X = data['data'].copy().sample(frac=1).reset_index(drop=True)
        class_names = data['class_names']
        target = data['target']

        custom_distribution = kwargs.get(
            'distribution', [[1/self.vector_dimension]*self.vector_dimension]*len(class_names))

        assert len(custom_distribution) == len(class_names)
        assert isinstance(custom_distribution, list)
        for distribution in custom_distribution:
            assert isinstance(distribution, list)
            assert len(distribution) == self.vector_dimension
            assert sum(distribution) == 1
        ic('Custom Distribution: ', custom_distribution)

        data_grouped_by_class = []
        for name in class_names:
            data_grouped_by_class.append(
                X[X[target] == name].copy().sample(
                    frac=1).reset_index(drop=True)
            )
        assert len(data_grouped_by_class) == len(class_names)
        # Split the data into $vector_dimension$ groups based on the dirichlet distribution

        data_split = []
        start_index_for_class = [0]*len(class_names)

        for agent_id in range(self.vector_dimension):
            private_agent_df = pd.DataFrame(columns=X.columns)
            for class_id in range(len(class_names)):
                start_index = start_index_for_class[class_id]
                current_data_group = data_grouped_by_class[class_id]
                current_distribution = custom_distribution[class_id][agent_id]
                ic(f'Agent ID :{agent_id} class_id: {class_id}: Fraction: {current_distribution}')
                n_samples = ceil(len(current_data_group)
                                 * current_distribution)
                end_index = start_index+n_samples
                X_sample = current_data_group.iloc[start_index:end_index]
                start_index_for_class[class_id] = end_index
                private_agent_df = pd.concat([private_agent_df, X_sample])

            private_agent_df.sample(frac=1)
            private_agent_df.reset_index(drop=True, inplace=True)
            data_split.append(private_agent_df)
        return data_split
