import numpy as np
def find_bucket(n,thresholds):
    for i in range(len(thresholds)-1):
        if n>=thresholds[i] and n<=thresholds[i+1]:
            return i
    if n>thresholds[-1]:
        return len(thresholds)-1
    return -1

def assign_group_id(data,sensitive_dict,cat_cols):
    if len(sensitive_dict.keys()) == 0:
        data['group_id'] = data.apply(lambda x: -1, axis=1)
        return data
    for key in sensitive_dict.keys():
        if key in cat_cols:
            print(f'Processing categorical attribute: {key}')
            data[key+'_new'] = data[key].apply(lambda x: str(x))
        else:
            print(f'Processing numerical attribute: {key}')
            thresholds = sensitive_dict[key]
            #sort the thresholds
            if np.array(thresholds).min() > data[key].min():
                thresholds.append(data[key].min())
            if np.array(thresholds).max() < data[key].max():
                thresholds.append(data[key].max())
            
            thresholds.sort()
            print(thresholds)
            data[key+'_new'] = data[key].apply(lambda x: find_bucket(x,thresholds))
            data[key+'_new'] = data[key+'_new'].apply(str)
       
        
    sensitive = [x+'_new' for x in sensitive_dict.keys()]
    #print(data[[sensitive]].unique())
    data['group']= data[sensitive].apply(lambda x: ''.join(x), axis=1)
    group_ids = {}
    current_id = 0
    for group in data['group'].unique():
        group_ids[group] = current_id
        current_id += 1
    data['group_id'] = data['group'].map(group_ids)
    data.drop(sensitive+['group'],axis=1,inplace=True)
    return data