from .base import BaseSplitter
from icecream import ic
import numpy as np
import pandas as pd
from math import ceil


class IIDSplitter(BaseSplitter):
    def __init__(self, *args, **kwargs) -> None:
        print("IIDSplitter created")
        super().__init__(*args, **kwargs)
        self.vector_dimension = kwargs.get('vector_dimension', 2)

    def split(self, data, **kwargs):
        assert data is not None
        X = data['data'].copy().sample(frac=1).reset_index(drop=True)
        iid_distribution = [1/self.vector_dimension]*self.vector_dimension
        ic('IID Distribution: ', iid_distribution)

        data_split = []
        start_index = 0
        for agent_id in range(self.vector_dimension):
            private_agent_df = pd.DataFrame(columns=X.columns)
            n_samples = ceil(len(X)*iid_distribution[agent_id])
            end_index = start_index + n_samples
            private_agent_df = pd.concat(
                [private_agent_df, X.iloc[start_index:end_index]])
            start_index = end_index
            private_agent_df.reset_index(drop=True, inplace=True)
            data_split.append(private_agent_df)
        return data_split
