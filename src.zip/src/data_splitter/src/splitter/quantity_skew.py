from .base import BaseSplitter
from icecream import ic
import numpy as np
import pandas as pd
from math import ceil


class QuantitySkewSplitter(BaseSplitter):
    def __init__(self, *args, **kwargs) -> None:
        print("QuantitySkewSplitter created")
        super().__init__(*args, **kwargs)
        self.alpha = kwargs.get('alpha', 0.1)
        self.vector_dimension = kwargs.get('vector_dimension', 2)

    def __sample_dirichlet(self, n_samples):
        dirichlet_vector = [self.alpha]*self.vector_dimension
        ic(dirichlet_vector)
        return np.random.dirichlet(dirichlet_vector, n_samples)

    def split(self, data, **kwargs):
        assert data is not None
        X = data['data'].copy().sample(frac=1).reset_index(drop=True)
        dirichlet_distribution = self.__sample_dirichlet(
            n_samples=1)[0]
        ic('Dirichlet Distribution: ', dirichlet_distribution)

        data_split = []
        start_index = 0

        for agent_id in range(self.vector_dimension):
            private_agent_df = pd.DataFrame(columns=X.columns)
            n_samples = ceil(len(X)*dirichlet_distribution[agent_id])
            end_index = start_index + n_samples
            private_agent_df = pd.concat(
                [private_agent_df, X.iloc[start_index:end_index]])
            start_index = end_index
            private_agent_df.reset_index(drop=True, inplace=True)
            data_split.append(private_agent_df)
        return data_split
