from .base import BaseSplitter
from icecream import ic
import numpy as np
import pandas as pd
from math import ceil
from itertools import product
from .utils import assign_group_id

class DirichletSplitter(BaseSplitter):
    def __init__(self, *args, **kwargs) -> None:
        print("DirichletSplitter created")
        super().__init__(*args, **kwargs)
        self.alpha = kwargs.get('alpha', 0.1)
        self.vector_dimension = kwargs.get('vector_dimension', 2)

    def __sample_dirichlet(self, n_samples):
        dirichlet_vector = [self.alpha]*self.vector_dimension
        ic(dirichlet_vector)
        return np.random.dirichlet(dirichlet_vector, n_samples)


    def split(self, data, **kwargs):
        # ic(data['data'].head())
        assert data is not None
        X = data['data']
        target = data['target']
        class_names = data['class_names']
        cat_cols = kwargs.get('cat_cols', [])
        attributes = kwargs.get('attributes', [])
        if len(attributes) > 0:
            print('Attributes provided, splitting based on attributes and target')
            split_attributes = {attr: X[attr].unique() for attr in attributes}
            data_groups = assign_group_id(X, split_attributes,cat_cols=cat_cols)
        else:
            print('No attributes provided, splitting based on the target only')
            split_attributes = {target: class_names}
            data_groups = assign_group_id(X, split_attributes,cat_cols=[target]+cat_cols)

        print('Split attributes: ',split_attributes)
        n_groups = len(data_groups['group_id'].unique())
        print('Number of groups: ',n_groups)
        dirichlet_distribution = self.__sample_dirichlet(
            n_samples=n_groups)
        ic(dirichlet_distribution)
        data_grouped_by_class = []
        for group_id in data_groups['group_id'].unique():
            data_grouped_by_class.append(
                data_groups[data_groups['group_id']==group_id].copy().sample(
                    frac=1).reset_index(drop=True)
            )
        assert len(data_grouped_by_class) == n_groups
        # Split the data into $vector_dimension$ groups based on the dirichlet distribution

        data_split = []
        start_index_for_class = [0]*n_groups

        for agent_id in range(self.vector_dimension):
            private_agent_df = pd.DataFrame(columns=X.columns)
            for group_id in range(n_groups):
                start_index = start_index_for_class[group_id]
                current_data_group = data_grouped_by_class[group_id]
                current_distribution = dirichlet_distribution[group_id][agent_id]
                ic(f'Agent ID :{agent_id} group_id: {group_id}: Fraction: {current_distribution}')
                n_samples = ceil(len(current_data_group)
                                 * current_distribution)
                end_index = start_index+n_samples
                X_sample = current_data_group.iloc[start_index:end_index]
                start_index_for_class[group_id] = end_index
                if len(private_agent_df) == 0:
                    private_agent_df = X_sample.copy()
                else:
                    private_agent_df = pd.concat([private_agent_df, X_sample])

            private_agent_df.sample(frac=1)
            private_agent_df.reset_index(drop=True, inplace=True)
            data_split.append(private_agent_df)

        return data_split
