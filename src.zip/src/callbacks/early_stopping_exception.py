class EarlyStoppingException(Exception):
    pass